
from __future__ import annotations
import os, re, time, json, sqlite3, hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import requests
import pandas as pd

BASE=Path(__file__).resolve().parent
DB=BASE/"data"/"corptrace_cache.sqlite"
DB.parent.mkdir(exist_ok=True)
QORPIQ_BASE="https://mcp.qorpiq.com/v1"
OGD_BASE="https://api.data.gov.in/resource"

class FreeSourceError(RuntimeError): pass

def _db():
    con=sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS cache(
        cache_key TEXT PRIMARY KEY, payload TEXT NOT NULL, source TEXT, fetched_at TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS source_calls(
        id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, status TEXT, detail TEXT, fetched_at TEXT)""")
    return con

def _log(source,status,detail):
    with _db() as con:
        con.execute("INSERT INTO source_calls(source,status,detail,fetched_at) VALUES(?,?,?,?)",
                    (source,status,str(detail)[:500],datetime.now(timezone.utc).isoformat()))

def _cached(key, ttl=24):
    with _db() as con:
        row=con.execute("SELECT payload,fetched_at FROM cache WHERE cache_key=?",(key,)).fetchone()
    if not row: return None
    try:
        age=datetime.now(timezone.utc)-datetime.fromisoformat(row[1])
        return json.loads(row[0]) if age.total_seconds()<ttl*3600 else None
    except Exception: return None

def _save(key, source, data):
    with _db() as con:
        con.execute("INSERT OR REPLACE INTO cache VALUES(?,?,?,?)",
                    (key,json.dumps(data,default=str),source,datetime.now(timezone.utc).isoformat()))


def _enforce_daily_limit(source: str, limit: int = 80):
    """Local safety guard kept below the provider's documented fair-use ceiling."""
    day=datetime.now(timezone.utc).date().isoformat()
    with _db() as con:
        count=con.execute(
            "SELECT COUNT(*) FROM source_calls WHERE source=? AND status='SUCCESS' AND substr(fetched_at,1,10)=?",
            (source,day)
        ).fetchone()[0]
    if count >= limit:
        raise FreeSourceError(f"{source} local daily safety limit reached ({limit} successful calls).")

def _get(url, params=None, timeout=20):
    # TLS certificate verification remains enabled.
    r=requests.get(url,params=params,timeout=timeout,verify=True,
                   headers={"User-Agent":"CORPTRACE/2.0 (read-only corporate data research)"})
    if r.status_code==429: raise FreeSourceError("Provider rate limit reached (HTTP 429). Wait before retrying.")
    if r.status_code==410: raise FreeSourceError("Provider indicates this profile was removed (HTTP 410).")
    r.raise_for_status()
    return r.json()

def qorpiq_search(name, limit=5):
    key="qorpiq:search:"+hashlib.sha256(name.strip().lower().encode()).hexdigest()
    hit=_cached(key,24)
    if hit is not None: return hit,"QorpIQ Free MCP/REST | SQLite cache"
    _enforce_daily_limit("QorpIQ",80)
    data=_get(QORPIQ_BASE+"/search",{"q":name,"limit":max(1,min(int(limit),10))})
    _save(key,"QorpIQ Free MCP/REST",data); _log("QorpIQ","SUCCESS",f"company search: {name}")
    return data,"QorpIQ Free MCP/REST | Live API"

def qorpiq_company(cin):
    cin=str(cin).strip().upper()
    if not cin: raise FreeSourceError("CIN/LLPIN is required.")
    key="qorpiq:company:"+cin
    hit=_cached(key,24)
    if hit is not None: return hit,"QorpIQ Free MCP/REST | SQLite cache"
    _enforce_daily_limit("QorpIQ",80)
    data=_get(QORPIQ_BASE+"/company/"+cin)
    _save(key,"QorpIQ Free MCP/REST",data); _log("QorpIQ","SUCCESS",f"company: {cin}")
    return data,"QorpIQ Free MCP/REST | Live API"

def qorpiq_director(din):
    din=re.sub(r"\D","",str(din))
    if len(din)!=8: raise FreeSourceError("DIN must contain exactly eight digits.")
    key="qorpiq:director:"+din
    hit=_cached(key,24)
    if hit is not None: return hit,"QorpIQ Free MCP/REST | SQLite cache"
    _enforce_daily_limit("QorpIQ",80)
    data=_get(QORPIQ_BASE+"/director/"+din)
    _save(key,"QorpIQ Free MCP/REST",data); _log("QorpIQ","SUCCESS",f"director: {din}")
    return data,"QorpIQ Free MCP/REST | Live API"

def qorpiq_status():
    return _get(QORPIQ_BASE+"/status")

def ogd_company_search(name, api_key, resource_id, name_field="CompanyName", limit=10):
    if not api_key or not resource_id:
        raise FreeSourceError("Enter your free data.gov.in API key and the active Company Master resource ID.")
    # OGD API filters are exact-match; fuzzy matching is performed locally by CORPTRACE.
    params={"api-key":api_key,"format":"json","limit":max(1,min(int(limit),100)),
            f"filters[{name_field}]":str(name).strip().upper()}
    key="ogd:"+resource_id+":"+hashlib.sha256(json.dumps(params,sort_keys=True).encode()).hexdigest()
    hit=_cached(key,24)
    if hit is not None: return hit,"data.gov.in OGD | SQLite cache"
    _enforce_daily_limit("data.gov.in",80)
    data=_get(f"{OGD_BASE}/{resource_id}",params=params)
    _save(key,"data.gov.in OGD",data); _log("data.gov.in","SUCCESS",f"company search: {name}")
    return data,"data.gov.in OGD | Live API"

def fetch_company(name, selected_sources, ogd_config=None):
    results=[]
    errors=[]
    ogd_config=ogd_config or {}
    if "QorpIQ Free" in selected_sources:
        try:
            data,source=qorpiq_search(name)
            results.append({"source":source,"payload":data})
        except Exception as e:
            errors.append(f"QorpIQ: {e}"); _log("QorpIQ","ERROR",e)
    if "data.gov.in OGD" in selected_sources:
        try:
            data,source=ogd_company_search(name,ogd_config.get("api_key"),ogd_config.get("resource_id"),
                ogd_config.get("name_field","CompanyName"))
            results.append({"source":source,"payload":data})
        except Exception as e:
            errors.append(f"data.gov.in: {e}"); _log("data.gov.in","ERROR",e)
    return results,errors

def fetch_director(din, selected_sources):
    results=[]; errors=[]
    if "QorpIQ Free" in selected_sources:
        try:
            data,source=qorpiq_director(din); results.append({"source":source,"payload":data})
        except Exception as e:
            errors.append(f"QorpIQ: {e}"); _log("QorpIQ","ERROR",e)
    if "data.gov.in OGD" in selected_sources:
        errors.append("data.gov.in Company Master Data does not include director/DIN details.")
    return results,errors


def split_source_label(label: str):
    """Return the provider name and retrieval mode without mislabelling cache as a provider."""
    text=str(label or "Unknown")
    if " | " in text:
        provider, mode=text.rsplit(" | ",1)
        return provider, mode
    if text == "SQLite cache":
        return "Unknown provider", "SQLite cache (legacy cache entry)"
    return text, "Live API (legacy label)"


def _as_record_list(value):
    if isinstance(value, list):
        return [x for x in value if isinstance(x, dict)]
    if isinstance(value, dict):
        return [value]
    return []


def extract_company_records(payload):
    """Extract only actual company records from a provider response; ignore envelopes/errors."""
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("results", "records", "companies", "data"):
        value=payload.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, dict)]
        if isinstance(value, dict):
            for nested in ("results", "records", "companies"):
                if isinstance(value.get(nested), list):
                    return [x for x in value[nested] if isinstance(x, dict)]
            if any(k in value for k in ("cin","CIN","name","company_name","companyName")):
                return [value]
    if any(k in payload for k in ("cin","CIN","name","company_name","companyName")):
        return [payload]
    return []


def extract_director_records(payload, lookup_din):
    """Return explicit profile and appointment records from QorpIQ's free director lookup."""
    if isinstance(payload, list):
        root={"appointments":payload}
    elif isinstance(payload, dict):
        root=payload
    else:
        return [], []
    profile=root.get("director_master_data") or root.get("director") or root.get("profile")
    if not isinstance(profile, dict):
        candidate={k:v for k,v in root.items() if k not in ("appointments","directorships","companies","records","data","results","source_url","next","transaction_id","timestamp")}
        meaningful={"din","name","director_name","full_name","din_status","status","is_disqualified","disqualification"}
        profile=candidate if any(str(k).lower() in meaningful for k in candidate) else {}
    appointments=[]
    for key in ("appointments","directorships","companies","records"):
        value=root.get(key)
        if isinstance(value,list):
            appointments=[x for x in value if isinstance(x,dict)]
            if appointments: break
    if not appointments and isinstance(root.get("data"),dict):
        data=root["data"]
        profile=profile or data.get("director_master_data") or data.get("director") or {}
        for key in ("appointments","directorships","companies","records"):
            if isinstance(data.get(key),list):
                appointments=[x for x in data[key] if isinstance(x,dict)]
                break
    elif not appointments and isinstance(root.get("data"),list):
        appointments=[x for x in root["data"] if isinstance(x,dict)]
    profile_rows=[]
    if isinstance(profile,dict) and profile:
        profile_rows=[{"Record Type":"Director Profile","Lookup DIN":str(lookup_din),**profile}]
    appointment_rows=[]
    for appointment in appointments:
        appointment_rows.append({"Record Type":"Director Appointment","Lookup DIN":str(lookup_din),**appointment})
    return profile_rows, appointment_rows


def _walk_dicts(node):
    """Yield dictionaries recursively from nested JSON payloads."""
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk_dicts(value)
    elif isinstance(node, list):
        for value in node:
            yield from _walk_dicts(value)


def _first_value(row, aliases):
    def key_norm(value):
        return re.sub(r"[^a-z0-9]","",str(value).lower())
    lowered={key_norm(k):v for k,v in row.items()}
    for alias in aliases:
        key=key_norm(alias)
        if key in lowered and lowered[key] not in (None,""):
            return lowered[key]
    return ""


def normalize_company_candidates(payload, query="", provider="QorpIQ Free MCP/REST", mode="Live API"):
    """Extract actual company candidates from QorpIQ free name-search JSON."""
    candidates=[]
    for row in _walk_dicts(payload):
        cin=_first_value(row,("cin","llpin","fcrn","identifier","company_id"))
        name=_first_value(row,("company_name","name","legal_name","entity_name","company"))
        # Avoid mistaking director rows or metadata for company candidates.
        if not cin or not name:
            continue
        identifier=str(cin).strip().upper()
        if not (len(identifier) in (6,21) or re.fullmatch(r"[A-Z0-9-]{6,21}",identifier)):
            continue
        candidates.append({
            "Input Company Name":str(query),
            "Legal Company Name":str(name).strip(),
            "CIN/LLPIN":identifier,
            "Company Status":str(_first_value(row,("company_status","status","status_of_company"))),
            "State":str(_first_value(row,("state","roc_state","registered_state"))),
            "Date of Incorporation":str(_first_value(row,("date_of_incorporation","incorporation_date","date_of_registration"))),
            "Source URL":str(_first_value(row,("source_url","url"))),
            "Provider":provider,
            "Retrieval Mode":mode,
        })
    # Stable de-duplication by identifier
    unique={}
    for item in candidates:
        unique.setdefault(item["CIN/LLPIN"],item)
    return list(unique.values())


def extract_company_board_directors(payload, cin="", company_name=""):
    """Extract director rows explicitly present in a QorpIQ free company-by-CIN response.

    Only arrays under director/board/principal keys are treated as board records.
    The parser never infers directors from unrelated company fields.
    """
    director_rows=[]
    director_keys={"directors","director_details","board","board_of_directors","board_members",
                   "current_directors","past_directors","principals","directors_list"}
    root_source_url=""
    for candidate in _walk_dicts(payload):
        root_source_url = _first_value(candidate,("source_url","sourceUrl","url"))
        if root_source_url:
            break
    def visit(node):
        if isinstance(node,dict):
            for key,value in node.items():
                k=re.sub(r"[^a-z0-9]","",str(key).lower())
                director_key_norm={re.sub(r"[^a-z0-9]","",x) for x in director_keys}
                if k in director_key_norm and isinstance(value,list):
                    for rec in value:
                        if isinstance(rec,dict):
                            din=_first_value(rec,("din","director_id","director_identification_number"))
                            name=_first_value(rec,("director_name","name","full_name","name_of_director"))
                            if not din and not name:
                                continue
                            current_flag=_first_value(rec,("current","is_current"))
                            status_value=_first_value(rec,("status","director_status","current_status"))
                            if not status_value and current_flag != "":
                                status_value="Current" if str(current_flag).lower() in ("true","1","yes") else "Historical"
                            director_rows.append({
                                "Director Name":str(name).strip(),
                                "DIN":str(din).strip(),
                                "Designation":str(_first_value(rec,("designation","designation_category","role"))),
                                "Appointment Date":str(_first_value(rec,("appointment_date","appointed_on","date_of_appointment"))),
                                "Cessation Date":str(_first_value(rec,("cessation_date","ceased_on","date_of_cessation"))),
                                "Director Status":str(status_value),
                                "CIN/LLPIN":str(cin).strip().upper(),
                                "Company Name":str(company_name).strip(),
                                "Source URL":str(_first_value(rec,("source_url","url")) or root_source_url),
                            })
                visit(value)
        elif isinstance(node,list):
            for item in node:
                visit(item)
    visit(payload)
    # A response might put the board array at root under a singular `board` object.
    # Search nested dicts for known arrays while avoiding generic `records` arrays.
    seen=set()
    out=[]
    for row in director_rows:
        din=re.sub(r"\D","",row["DIN"])
        key=(din,row["Director Name"],row["CIN/LLPIN"])
        if key not in seen:
            seen.add(key)
            if din:
                row["DIN"]=din.zfill(8) if len(din)<=8 else din
            out.append(row)
    return out


def normalize_company_master(payload):
    """Return one company master object when present in a lookup_company response."""
    preferred={"companymasterdata","company","companydetails","masterdata","entity"}
    for row in _walk_dicts(payload):
        for key,value in row.items():
            normalized=re.sub(r"[^a-z0-9]","",str(key).lower())
            if normalized in preferred and isinstance(value,dict):
                return value
        if any(str(k).lower() in ("cin","llpin","company_name","legal_name") for k in row):
            return row
    return {}
