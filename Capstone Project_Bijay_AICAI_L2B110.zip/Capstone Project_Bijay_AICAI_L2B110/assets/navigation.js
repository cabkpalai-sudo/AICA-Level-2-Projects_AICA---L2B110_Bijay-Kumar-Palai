(function () {
  "use strict";
  let pendingTarget = null;
  let scrollTimer = null;

  function setActive(id) {
    document.querySelectorAll(".sidebar a.nav-item[href^='#']").forEach(function (a) {
      const active = a.getAttribute("href") === "#" + id;
      a.classList.toggle("active", active);
      if (active) a.setAttribute("aria-current", "location");
      else a.removeAttribute("aria-current");
    });
  }

  function scrollToTarget(id, retry) {
    if (!id) return;
    const target = document.getElementById(id);
    if (target) {
      pendingTarget = null;
      target.scrollIntoView({ behavior: "smooth", block: "start" });
      setActive(id);
      return;
    }
    // Analysis sections are created by a Dash callback. Scroll to the results
    // container now, then the MutationObserver will finish the jump when ready.
    pendingTarget = id;
    const results = document.getElementById("results-area");
    if (results) results.scrollIntoView({ behavior: "smooth", block: "start" });
    setActive(id);
    if (retry) {
      window.clearTimeout(scrollTimer);
      scrollTimer = window.setTimeout(function () {
        if (pendingTarget === id) scrollToTarget(id, false);
      }, 700);
    }
  }

  document.addEventListener("click", function (event) {
    const link = event.target.closest(".sidebar a.nav-item[href^='#']");
    if (!link) return;
    const id = link.getAttribute("href").slice(1);
    if (!id) return;
    event.preventDefault();
    if (window.location.hash !== "#" + id) {
      history.pushState(null, "", "#" + id);
    }
    scrollToTarget(id, true);
  });

  window.addEventListener("hashchange", function () {
    scrollToTarget(window.location.hash.slice(1), true);
  });
  window.addEventListener("popstate", function () {
    scrollToTarget(window.location.hash.slice(1), true);
  });

  const observer = new MutationObserver(function () {
    if (pendingTarget && document.getElementById(pendingTarget)) {
      scrollToTarget(pendingTarget, false);
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  document.addEventListener("DOMContentLoaded", function () {
    if (window.location.hash) scrollToTarget(window.location.hash.slice(1), true);
  });
})();
