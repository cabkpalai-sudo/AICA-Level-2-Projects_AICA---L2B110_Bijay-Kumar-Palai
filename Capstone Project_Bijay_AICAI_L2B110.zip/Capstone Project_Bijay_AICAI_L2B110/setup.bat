@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv
  if errorlevel 1 goto error
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto error
python -m pip install -r requirements.txt
if errorlevel 1 goto error
echo.
echo CORPTRACE 2.0 setup completed successfully.
pause
exit /b 0
:error
echo.
echo Setup failed. Check Python 3.10+ 64-bit installation and internet connection.
pause
exit /b 1
