# CORPTRACE 2.0 — Change Log

## Major workflow redesign
- Renamed CORPINTEL to CORPTRACE — Corporate & Director Intelligence.
- Company name list is now the only mandatory input.
- Added company-name search and candidate review table.
- Added explicit auditor selection/confirmation of company legal name and CIN/LLPIN.
- Added company-by-CIN lookup through QorpIQ Free MCP to retrieve board/director rows and DINs where the returned company profile contains them.
- Removed mandatory dependency on a pre-uploaded Director Register for director discovery.
- Kept optional Director Register upload as supplementary/fallback input.
- Common-director analysis uses DIN and confirmed CIN/LLPIN.
- Added source provider, retrieval mode and retrieval timestamp to fetched evidence.
- Retained optional data.gov.in company-master connector; it is never used as a director source.
- Updated Windows setup/run scripts, sample company-name-only CSV, optional register template and evidence workbook branding.
