
import base64, io
from pathlib import Path
import pandas as pd
from corptrace_core import read_upload, director_analysis, resolve_company_names

DATA=Path(__file__).resolve().parents[1]/"data"

def as_upload(text, filename="test.csv"):
    return "data:text/csv;base64,"+base64.b64encode(text.encode("utf-8")).decode(), filename

def test_csv_upload_preserves_leading_zero_din():
    contents, filename=as_upload("Director Name,DIN,CIN,Status\nAarav,01234567,CIN1,Active\n")
    df=read_upload(contents,filename)
    assert df.loc[0,"DIN"]=="01234567"

def test_common_directors_detected():
    csv=("Director Name,DIN,CIN,Status\n"
         "Aarav Mehta,01234567,CIN1,Active\n"
         "Aarav Mehta,01234567,CIN2,Active\n"
         "Nisha Rao,02345678,CIN1,Active\n"
         "Nisha Rao,02345678,CIN3,Ceased\n"
         "Kabir Shah,03456789,CIN4,Active\n"
         "Kabir Shah,03456789,CIN5,Active\n"
         "Invalid Person,1234567,CIN6,Active\n")
    contents,filename=as_upload(csv)
    df=read_upload(contents,filename)
    clean,common=director_analysis(df)
    assert len(common)==3
    assert set(common["DIN"])=={"01234567","02345678","03456789"}
    assert int(common.loc[common["DIN"]=="01234567","Company_Count"].iloc[0])==2

def test_invalid_seven_digit_din_is_retained_but_excluded_from_common():
    contents,filename=as_upload("Director Name,DIN,CIN,Status\nInvalid Person,1234567,CIN1,Active\n")
    df=read_upload(contents,filename)
    clean,common=director_analysis(df)
    assert clean.loc[0,"DIN Validation"]=="INVALID FORMAT"
    assert common.empty

def test_historical_status_is_identified():
    csv=("Director Name,DIN,CIN,Status\n"
         "Nisha Rao,02345678,CIN1,Active\n"
         "Nisha Rao,02345678,CIN2,Ceased\n")
    contents,filename=as_upload(csv)
    df=read_upload(contents,filename)
    _,common=director_analysis(df)
    status=common.iloc[0]["Link_Status"]
    assert "ACTIVE" in status and "HISTORICAL" in status

def test_company_matching_from_local_fixture():
    companies=pd.read_csv(DATA/"sample_company_list.csv",dtype=str,keep_default_na=False)
    master=pd.DataFrame([
        {"Company Name":"Tata Steel Limited","CIN":"L27100OR1907PLC000260"},
        {"Company Name":"Infosys Limited","CIN":"L85110KA1981PLC013115"},
        {"Company Name":"Reliance Industries Limited","CIN":"L17110MH1973PLC019786"},
    ],dtype=str)
    result=resolve_company_names(companies,master)
    assert len(result)==3
    assert (result["Match Status"]=="MATCHED").sum()==3

def test_dash_json_roundtrip_preserves_leading_zero_din():
    contents,filename=as_upload("Director Name,DIN,CIN,Status\nAarav,01234567,CIN1,Active\nAarav,01234567,CIN2,Active\n")
    df=read_upload(contents,filename)
    stored=df.to_json(orient="split")
    restored=pd.read_json(io.StringIO(stored),orient="split",dtype=False)
    assert restored.loc[0,"DIN"]=="01234567"
    _,common=director_analysis(restored)
    assert len(common)==1


def test_company_name_only_input_is_valid():
    contents,filename=as_upload("Company Name\nTata Steel Limited\nInfosys Limited\n")
    df=read_upload(contents,filename)
    assert list(df.columns)==["Company Name"]
    assert len(df)==2

def test_director_analysis_uses_confirmed_cin_and_leading_zero_din():
    csv=("Director Name,DIN,CIN/LLPIN,Company Name,Designation,Director Status\n"
         "Aarav Example,01234567,L27100OR1907PLC000260,Tata Steel Limited,Director,Active\n"
         "Aarav Example,01234567,L85110KA1981PLC013115,Infosys Limited,Director,Active\n")
    contents,filename=as_upload(csv)
    df=read_upload(contents,filename)
    details,common=director_analysis(df)
    assert details.loc[0,"DIN Clean"]=="01234567"
    assert len(common)==1
    assert common.iloc[0]["Company_Count"]==2
