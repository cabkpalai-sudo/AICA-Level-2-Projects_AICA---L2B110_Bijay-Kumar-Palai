
import pytest
import source_engine

class FakeResponse:
    status_code=200
    def raise_for_status(self): pass
    def json(self): return {"records":[{"CIN":"TESTCIN","CompanyName":"Test Ltd"}]}

def test_https_verification_enabled(monkeypatch):
    seen={}
    def fake_get(url, **kwargs):
        seen.update(kwargs)
        return FakeResponse()
    monkeypatch.setattr(source_engine.requests,"get",fake_get)
    result=source_engine._get("https://example.invalid/test")
    assert result["records"][0]["CIN"]=="TESTCIN"
    assert seen["verify"] is True

def test_bad_din_rejected_before_network():
    with pytest.raises(source_engine.FreeSourceError):
        source_engine.qorpiq_director("1234567")


def test_source_engine_database_initializer_creates_tables(tmp_path, monkeypatch):
    # Verify the same SQLite initializer used by app startup is callable.
    import sqlite3
    db = tmp_path / "corpintel.sqlite"
    monkeypatch.setattr(source_engine, "DB", db)
    con = source_engine._db()
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    con.close()
    assert {"cache", "source_calls"}.issubset(tables)


def test_cached_source_label_preserves_provider_provenance():
    provider, mode = source_engine.split_source_label("QorpIQ Free MCP/REST | SQLite cache")
    assert provider == "QorpIQ Free MCP/REST"
    assert mode == "SQLite cache"

def test_live_source_label_is_not_misreported_as_cache():
    provider, mode = source_engine.split_source_label("QorpIQ Free MCP/REST | Live API")
    assert provider == "QorpIQ Free MCP/REST"
    assert mode == "Live API"

def test_company_payload_parser_does_not_turn_error_envelope_into_company():
    assert source_engine.extract_company_records({"error":"not found","message":"missing"}) == []
    rows = source_engine.extract_company_records({"results":[{"cin":"CIN1","name":"Example Ltd"}]})
    assert len(rows) == 1 and rows[0]["cin"] == "CIN1"

def test_director_payload_parser_extracts_profile_and_appointments():
    payload = {
        "director_master_data": {"din":"01234567","name":"Test Director","din_status":"Active"},
        "appointments": [{"cin":"CIN1","company_name":"One Ltd","status":"Active"},
                         {"cin":"CIN2","company_name":"Two Ltd","status":"Ceased"}]
    }
    profiles, appointments = source_engine.extract_director_records(payload,"01234567")
    assert profiles[0]["Record Type"] == "Director Profile"
    assert len(appointments) == 2
    assert appointments[0]["Lookup DIN"] == "01234567"

def test_data_gov_company_master_is_not_used_for_director_lookup():
    results, errors = source_engine.fetch_director("01234567", ["data.gov.in OGD"])
    assert results == []
    assert any("does not include director/DIN" in e for e in errors)

def test_ogd_blank_credentials_fail_before_network():
    with pytest.raises(source_engine.FreeSourceError, match="API key and the active Company Master"):
        source_engine.ogd_company_search("Example Ltd", "", "", "CompanyName")

def test_director_analysis_uses_company_name_when_cin_blank():
    import pandas as pd
    from corptrace_core import director_analysis
    df = pd.DataFrame([
        {"DIN":"01234567","Director Name":"Test Person","CIN":"","Company Name":"Company A","Status":"Active"},
        {"DIN":"01234567","Director Name":"Test Person","CIN":"","Company Name":"Company B","Status":"Ceased"},
    ], dtype=str)
    details, common = director_analysis(df)
    assert len(common) == 1
    assert int(common.iloc[0]["Company_Count"]) == 2

def test_sidebar_navigation_script_handles_deferred_dash_sections():
    from pathlib import Path
    script=(Path(__file__).resolve().parents[1]/"assets"/"navigation.js").read_text(encoding="utf-8")
    assert "MutationObserver" in script
    assert "scrollIntoView" in script
    assert "pendingTarget" in script


def test_director_parser_does_not_promote_metadata_to_profile():
    profiles, appointments = source_engine.extract_director_records(
        {"source_url":"https://example.invalid/profile","next":"retry"}, "01234567"
    )
    assert profiles == []
    assert appointments == []


def test_free_qorpiq_director_endpoint_is_read_only_get_without_api_key(tmp_path, monkeypatch):
    db = tmp_path / "qorpiq.sqlite"
    monkeypatch.setattr(source_engine, "DB", db)
    seen={}
    class Response:
        status_code=200
        def raise_for_status(self): pass
        def json(self):
            return {"director_master_data":{"din":"01234567","name":"Example Director"},
                    "appointments":[{"cin":"CIN001","company_name":"Example Ltd","status":"Active"}]}
    def fake_get(url, **kwargs):
        seen["url"]=url
        seen.update(kwargs)
        return Response()
    monkeypatch.setattr(source_engine.requests,"get",fake_get)
    payload, label=source_engine.qorpiq_director("01234567")
    assert seen["url"].endswith("/v1/director/01234567")
    assert seen["verify"] is True
    assert "x-api-key" not in seen.get("headers",{})
    assert "Live API" in label
    assert payload["director_master_data"]["din"]=="01234567"

def test_app_uses_company_name_only_then_confirmed_cin_for_directors():
    from pathlib import Path
    app_text=(Path(__file__).resolve().parents[1]/"app.py").read_text(encoding="utf-8")
    assert 'Input("search-company-btn","n_clicks")' in app_text
    assert 'Input("fetch-directors-btn","n_clicks")' in app_text
    assert 'source_engine.qorpiq_company(cin)' in app_text
    assert 'Director Register  ·  Optional' in app_text
    assert 'Director Register containing DINs first' not in app_text
    assert 'director_analysis(director_raw)' in app_text


def test_company_search_candidate_normalization():
    payload={"results":[
        {"company_name":"TATA STEEL LIMITED","cin":"L27100OR1907PLC000260","company_status":"Active","state":"Odisha"},
        {"company_name":"TATA STEEL LONG PRODUCTS LIMITED","cin":"L27100JH1982PLC003739"}
    ]}
    rows=source_engine.normalize_company_candidates(payload,"Tata Steel","QorpIQ Free MCP/REST","Live API")
    assert len(rows)==2
    assert rows[0]["Legal Company Name"]=="TATA STEEL LIMITED"
    assert rows[0]["CIN/LLPIN"]=="L27100OR1907PLC000260"
    assert rows[0]["Company Status"]=="Active"

def test_company_by_cin_board_director_extraction():
    payload={"data":{"company_master_data":{"company_name":"TATA STEEL LIMITED","cin":"L27100OR1907PLC000260"},
        "board":[
            {"director_name":"Aarav Example","din":"01234567","designation":"Director","appointed_on":"2020-01-01","current":True},
            {"director_name":"Nisha Example","din":"02345678","designation":"Independent Director","appointed_on":"2021-03-10","ceased_on":"","current":True}
        ]}}
    rows=source_engine.extract_company_board_directors(payload,"L27100OR1907PLC000260","TATA STEEL LIMITED")
    assert len(rows)==2
    assert rows[0]["DIN"]=="01234567"
    assert rows[0]["Designation"]=="Director"
    assert rows[1]["Appointment Date"]=="2021-03-10"
    assert rows[1]["CIN/LLPIN"]=="L27100OR1907PLC000260"

def test_company_board_without_directors_returns_empty_not_inferred():
    payload={"company_master_data":{"company_name":"Example Ltd","cin":"L0000000000"}}
    assert source_engine.extract_company_board_directors(payload,"L0000000000","Example Ltd")==[]

def test_source_cache_label_is_not_live():
    provider,mode=source_engine.split_source_label("QorpIQ Free MCP/REST | SQLite cache")
    assert provider=="QorpIQ Free MCP/REST"
    assert mode=="SQLite cache"


def test_qorpiq_company_by_cin_is_free_read_only_get_and_returns_board(tmp_path, monkeypatch):
    db=tmp_path/"company.sqlite"
    monkeypatch.setattr(source_engine,"DB",db)
    seen={}
    class Response:
        status_code=200
        def raise_for_status(self): pass
        def json(self):
            return {"company":{"name":"Example Limited","cin":"L12345678901234567890"},
                    "board":[{"name":"Director A","din":"01234567","designation":"Director"}]}
    def fake_get(url,**kwargs):
        seen["url"]=url; seen.update(kwargs); return Response()
    monkeypatch.setattr(source_engine.requests,"get",fake_get)
    payload,label=source_engine.qorpiq_company("L12345678901234567890")
    assert seen["url"].endswith("/v1/company/L12345678901234567890")
    assert seen["verify"] is True
    assert "x-api-key" not in seen.get("headers",{})
    assert "Live API" in label
    directors=source_engine.extract_company_board_directors(payload,"L12345678901234567890","Example Limited")
    assert len(directors)==1 and directors[0]["DIN"]=="01234567"

def test_board_parser_normalizes_numeric_seven_digit_din_as_zero_padded_eight():
    rows=source_engine.extract_company_board_directors(
        {"directors":[{"director_name":"Zero Lead","din":1234567}]},
        "L12345678901234567890","Example Ltd")
    assert rows[0]["DIN"]=="01234567"

def test_company_candidate_rejects_rows_without_cin():
    rows=source_engine.normalize_company_candidates(
        {"results":[{"company_name":"No CIN Ltd"},{"company_name":"Yes Ltd","cin":"L12345678901234567890"}]},
        "Example")
    assert len(rows)==1
    assert rows[0]["Legal Company Name"]=="Yes Ltd"


def test_branding_and_company_name_only_primary_input():
    from pathlib import Path
    app_text=(Path(__file__).resolve().parents[1]/"app.py").read_text(encoding="utf-8")
    assert 'title="CORPTRACE | Corporate & Director Intelligence"' in app_text
    assert 'Company name list  ·  Required' in app_text
    assert 'Director Register  ·  Optional' in app_text
    assert 'source_engine.qorpiq_company(cin)' in app_text
    assert 'Confirm selected companies & fetch directors' in app_text

def test_company_search_uses_published_free_endpoint_without_api_key(tmp_path,monkeypatch):
    db=tmp_path/"search.sqlite"
    monkeypatch.setattr(source_engine,"DB",db)
    seen={}
    class Response:
        status_code=200
        def raise_for_status(self): pass
        def json(self): return {"results":[{"company_name":"Example Limited","cin":"L12345678901234567890"}]}
    def fake_get(url,**kwargs):
        seen["url"]=url; seen.update(kwargs); return Response()
    monkeypatch.setattr(source_engine.requests,"get",fake_get)
    payload,label=source_engine.qorpiq_search("Example Limited")
    assert "/v1/search" in seen["url"]
    assert seen["params"]["q"]=="Example Limited"
    assert "x-api-key" not in seen.get("headers",{})
    assert "Live API" in label
    rows=source_engine.normalize_company_candidates(payload,"Example Limited")
    assert rows[0]["CIN/LLPIN"]=="L12345678901234567890"


def test_company_candidate_parser_supports_camel_case_fields():
    rows=source_engine.normalize_company_candidates(
        {"data":{"companies":[{"companyName":"Camel Case Limited","cin":"L12345678901234567890","companyStatus":"Active"}]}},
        "Camel Case")
    assert rows[0]["Legal Company Name"]=="Camel Case Limited"
    assert rows[0]["Company Status"]=="Active"

def test_board_parser_supports_camel_case_directors_array():
    rows=source_engine.extract_company_board_directors(
        {"companyMasterData":{"companyName":"Camel Ltd"},"boardMembers":[
            {"directorName":"Example Person","din":"01234567","designation":"Director"}]},
        "L12345678901234567890","Camel Ltd")
    assert len(rows)==1
    assert rows[0]["Director Name"]=="Example Person"
    assert rows[0]["DIN"]=="01234567"
