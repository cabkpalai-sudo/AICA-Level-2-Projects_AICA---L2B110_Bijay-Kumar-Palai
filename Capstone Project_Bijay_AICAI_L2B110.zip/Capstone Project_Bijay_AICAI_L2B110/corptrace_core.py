
from __future__ import annotations
import base64, io, re
from typing import Any
import pandas as pd
from rapidfuzz import process, fuzz

def norm_name(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    s = str(value).upper().strip()
    s = s.replace("&", " AND ")
    s = re.sub(r"[^A-Z0-9 ]", " ", s)
    s = re.sub(r"\b(PRIVATE|PVT|LIMITED|LTD|LLP|LLC|INCORPORATED|INC)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def clean_din(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    # Preserve leading zeros: input must be read as text before this function.
    s = re.sub(r"\D", "", str(value).strip())
    return s if len(s) == 8 else ""

def find_col(df: pd.DataFrame, candidates: list[str]):
    mapping = {str(c).strip().lower().replace("_"," ").replace("-"," "): c for c in df.columns}
    for cand in candidates:
        key = cand.lower().replace("_"," ").replace("-"," ")
        if key in mapping:
            return mapping[key]
    for key, original in mapping.items():
        if any(c.lower() in key for c in candidates):
            return original
    return None

def read_upload(contents: str, filename: str) -> pd.DataFrame:
    _, encoded = contents.split(",", 1)
    raw = base64.b64decode(encoded)
    if filename.lower().endswith(".csv"):
        return pd.read_csv(io.BytesIO(raw), dtype=str, keep_default_na=False)
    if filename.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(io.BytesIO(raw), dtype=str, keep_default_na=False)
    raise ValueError("Upload an Excel (.xlsx/.xls) or CSV file.")

def resolve_company_names(upload_df: pd.DataFrame, master_df: pd.DataFrame,
                          threshold: int = 90, review_threshold: int = 75) -> pd.DataFrame:
    in_col = find_col(upload_df, ["Company Name", "Company", "Name"])
    if in_col is None:
        raise ValueError("Input file must contain a column named Company Name (or Company/Name).")
    out = upload_df.copy()
    out["Input Company Name"] = out[in_col].astype(str)
    out["_norm"] = out["Input Company Name"].map(norm_name)
    if master_df.empty:
        out["Matched Legal Name"] = ""
        out["CIN/LLPIN"] = ""
        out["Match Confidence"] = 0
        out["Match Status"] = "MASTER DATA REQUIRED"
        out["Match Method"] = "No company master loaded"
        return out.drop(columns=["_norm"])
    m_name = find_col(master_df, ["Company Name", "Name", "Company"])
    m_id = find_col(master_df, ["CIN", "LLPIN", "Corporate Identification Number"])
    if not m_name:
        raise ValueError("Master data must contain a Company Name column.")
    master = master_df.copy()
    master["_norm"] = master[m_name].map(norm_name)
    choices = master["_norm"].dropna().unique().tolist()
    results = []
    for _, row in out.iterrows():
        q = row["_norm"]
        best = process.extractOne(q, choices, scorer=fuzz.WRatio) if q and choices else None
        if best:
            matched_norm, score, _ = best
            candidate = master[master["_norm"] == matched_norm].iloc[0]
            legal = candidate[m_name]
            cin = candidate[m_id] if m_id else ""
            status = "MATCHED" if score >= threshold else ("REVIEW REQUIRED" if score >= review_threshold else "UNMATCHED")
            method = "Exact normalized" if q == matched_norm else "RapidFuzz WRatio"
        else:
            score, legal, cin, status, method = 0, "", "", "UNMATCHED", "No candidate"
        results.append((legal, cin, round(float(score), 1), status, method))
    out[["Matched Legal Name","CIN/LLPIN","Match Confidence","Match Status","Match Method"]] = pd.DataFrame(results,index=out.index)
    return out.drop(columns=["_norm"])

def director_analysis(directors: pd.DataFrame):
    if directors.empty:
        return pd.DataFrame(), pd.DataFrame()
    d = directors.copy()
    din_col = find_col(d, ["DIN", "Director Identification Number"])
    company_id_col = find_col(d, ["CIN", "LLPIN", "Company ID"])
    company_name_col = find_col(d, ["Company Name", "Company"])
    name_col = find_col(d, ["Director Name", "Name"])
    if not din_col:
        raise ValueError("Director file needs a DIN column.")
    d["DIN Clean"] = d[din_col].map(clean_din)
    d["DIN Validation"] = d["DIN Clean"].apply(lambda x: "VALID FORMAT" if x else "INVALID FORMAT")
    invalid_count = int((d["DIN Clean"] == "").sum())
    d = d[d["DIN Clean"] != ""].copy()
    if name_col:
        d["Director Name Standard"] = d[name_col].astype(str).str.strip()
    else:
        d["Director Name Standard"] = "Not supplied"
    if company_id_col:
        d["Company Key"] = d[company_id_col].astype(str).str.strip()
        if company_name_col:
            blank_key = d["Company Key"].eq("") | d["Company Key"].str.lower().eq("nan")
            d.loc[blank_key, "Company Key"] = d.loc[blank_key, company_name_col].astype(str).str.strip()
    elif company_name_col:
        d["Company Key"] = d[company_name_col].astype(str).str.strip()
    else:
        d["Company Key"] = ""
    d = d[d["Company Key"].ne("") & d["Company Key"].str.lower().ne("nan")].copy()
    status_col = find_col(d, ["Status", "Director Status", "Appointment Status"])
    if status_col:
        d["Link Status"] = d[status_col].astype(str).str.upper().apply(
            lambda x: "HISTORICAL" if any(t in x for t in ["CEASED","RESIGNED","PAST","FORMER","INACTIVE","CESSATION","ENDED"]) else
                      ("ACTIVE" if any(t in x for t in ["ACTIVE","CURRENT"]) else "UNVERIFIED"))
    else:
        d["Link Status"] = "UNVERIFIED"
    agg = d.groupby("DIN Clean").agg(
        Director=("Director Name Standard","first"),
        Company_Count=("Company Key","nunique"),
        Companies=("Company Key",lambda x:" | ".join(sorted(set(x)))),
        Link_Status=("Link Status",lambda x:" / ".join(sorted(set(x)))),
    ).reset_index().rename(columns={"DIN Clean":"DIN"})
    agg["Connectivity Class"] = agg["Company_Count"].apply(
        lambda n:"HIGH CONNECTIVITY" if n>=5 else ("COMMON DIRECTOR" if n>=2 else "SINGLE COMPANY"))
    common = agg[agg["Company_Count"]>=2].sort_values(
        ["Company_Count","Director"],ascending=[False,True])
    # Keep invalid rows available for the Director Details tab/report.
    invalid = directors.copy()
    invalid["DIN Validation"] = invalid[din_col].map(clean_din).apply(
        lambda x: "VALID FORMAT" if x else "INVALID FORMAT")
    clean_all = directors.copy()
    clean_all["DIN Clean"] = clean_all[din_col].map(clean_din)
    clean_all["DIN Validation"] = clean_all["DIN Clean"].apply(
        lambda x: "VALID FORMAT" if x else "INVALID FORMAT")
    return clean_all, common
