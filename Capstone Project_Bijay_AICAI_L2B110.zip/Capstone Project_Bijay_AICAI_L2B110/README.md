# CORPTRACE 2.0 — Corporate & Director Intelligence

**Windows desktop-local web application | Python + Plotly Dash | Zero-paid-API design**

CORPTRACE starts with a list of company names. It resolves candidate legal entities and CIN/LLPINs, lets the auditor confirm the correct entity, then looks up the company's board/director records by the confirmed CIN/LLPIN. A Director Register upload is optional only.

## Primary audit workflow

1. Prepare an Excel or CSV file with one required column: `Company Name`.
2. In CORPTRACE, upload that file.
3. Select the permitted public data source(s), then click **Search company names**.
4. Review the candidate legal names, CIN/LLPINs, match confidence, provider and retrieval mode.
5. Select the correct candidate rows. This is the auditor's explicit entity-confirmation step.
6. Click **Confirm selected companies & fetch directors**.
7. CORPTRACE calls the free QorpIQ company-by-CIN endpoint and extracts only director/board rows explicitly returned in the company record. DINs, designations and appointment/cessation dates are shown only when the provider response contains them.
8. Click **Run common-director analysis** to identify repeated DINs across the confirmed companies.
9. Download the Excel audit evidence workbook.

The optional Director Register is supplementary/fallback input. It is not required for the primary workflow.

## Free data sources

### QorpIQ Free MCP / REST — primary source
- QorpIQ documents its MCP as free, read-only, no-authentication and subject to a fair-use limit. Its published MCP repository states a limit of 100 tool calls per day per network address.
- Company name search: `GET https://mcp.qorpiq.com/v1/search?q={name}&limit=5`
- Company/board lookup by confirmed CIN/LLPIN: `GET https://mcp.qorpiq.com/v1/company/{cin}`
- Director lookup by DIN (not needed for the main company-to-board flow): `GET https://mcp.qorpiq.com/v1/director/{din}`
- CORPTRACE applies a local successful-call safety cap of 80 calls/day across QorpIQ endpoints, below the published 100-call fair-use limit.
- The free MCP documentation describes company lookup as returning a company record with board/DIN information. CORPTRACE extracts director rows from the board/principals/directors structures only when present in the response.
- QorpIQ states that its free MCP answers from its own held public-record data and does not fetch live from MCA. Therefore a `Live API` label means a fresh request to QorpIQ, not a live MCA portal lookup. Cached responses are separately labelled `SQLite cache`.
- Provider data can be incomplete, stale or absent. A no-director result means the response did not contain a supported board array; it is not proof that the company has no directors.

Official documentation:
- MCP server and free endpoints: https://developers.qorpiq.com/docs/mcp-server/
- QorpIQ MCP repository and tool descriptions: https://github.com/QorpIQ/mcp-server
- QorpIQ overview: https://qorpiq.com/mcp

### data.gov.in OGD Company Master — optional
- Optional company-master enrichment only.
- Requires a free data.gov.in API key and the exact active resource ID and field name for the selected resource.
- It is not used for director/DIN lookups.
- If the API key or resource ID is blank, CORPTRACE skips this provider and reports why.

## Source provenance and audit trail
For each retrieved record CORPTRACE records:
- Provider
- Retrieval mode (`Live API` or `SQLite cache`)
- Retrieval timestamp (UTC)
- Search query / CIN
- Source URL, when supplied by the provider

A cache hit is not a new API request. It is never represented as a fresh live fetch.

## Input files

### Required: company name list
One column: `Company Name`. A sample file is included at `data/sample_company_list.csv`.

### Optional: Director Register
Template: `data/optional_director_register_template.csv`.
Recommended columns: `Director Name`, `DIN`, `CIN`, `Company Name`, `Designation`, `Appointment Date`, `Cessation Date`, `Status`, `Source URL`, `Source Date`.
DINs are imported as text to preserve leading zeroes. An eight-digit check is a format check only, not proof of validity/current status.

## Evidence workbook
The downloadable workbook contains:
- Company Matching
- Confirmed Companies
- Director Details
- Common Directors
- Source Evidence
- Read Me & Limitations

## Windows installation
1. Extract the ZIP to a folder where you have write permission.
2. Install Python 3.10+ (64-bit) and ensure the Python Launcher (`py`) is available.
3. Double-click `setup.bat` once and wait for installation to finish.
4. Double-click `run.bat`.
5. Open `http://127.0.0.1:8050` in Chrome or Edge.
6. Upload `data/sample_company_list.csv`.
7. Click **Search company names**.
8. Select the correct candidate row(s), then click **Confirm selected companies & fetch directors**.
9. Click **Run common-director analysis**.
10. Download the evidence workbook.

## Automated tests
From the CORPTRACE folder:
```bat
.venv\Scripts\activate
python -m pytest -q tests
```

## Audit limitations and responsible use
- Public-source results are preliminary screening evidence. Verify material facts against current official MCA records or organizationally approved records before concluding.
- QorpIQ Free MCP data is QorpIQ-held public-record data, not a guaranteed live MCA query.
- Name similarity scores are candidate-ranking aids, not legal identity confirmation. The auditor must select/confirm the entity.
- If the company-by-CIN response contains no director/board rows, CORPTRACE reports no rows returned; it does not invent director names or DINs.
- Common directorship alone does not establish related-party status, control, conflict of interest, collusion or misconduct.
- Appointment/cessation dates and designations are blank unless actually supplied by the selected source.
- Do not bypass CAPTCHA, Cloudflare or other access controls.

## Commercial deployment note
This is a local prototype. Before commercial sale or multi-user deployment, complete security, licensing, privacy, backup/restore, audit-log, authentication/authorization, dependency and production-server reviews. The built-in Flask development server is for local testing only.
