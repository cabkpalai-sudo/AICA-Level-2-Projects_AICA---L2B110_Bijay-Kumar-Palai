
from __future__ import annotations
import io, json, os
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from rapidfuzz import fuzz
from dash import Dash, dcc, html, Input, Output, State, dash_table, no_update

import source_engine
from corptrace_core import clean_din, find_col, read_upload, resolve_company_names, director_analysis, norm_name

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
NAVY="#101B33"; BLUE="#315EFB"; GREEN="#15966B"; AMBER="#D99A20"

def init_db():
    con=source_engine._db()
    con.close()

def make_workbook(companies, confirmed, directors, common, evidence):
    buf=io.BytesIO()
    with pd.ExcelWriter(buf,engine="openpyxl") as writer:
        companies.to_excel(writer,index=False,sheet_name="Company Matching")
        confirmed.to_excel(writer,index=False,sheet_name="Confirmed Companies")
        directors.to_excel(writer,index=False,sheet_name="Director Details")
        common.to_excel(writer,index=False,sheet_name="Common Directors")
        if evidence:
            pd.json_normalize(evidence).to_excel(writer,index=False,sheet_name="Source Evidence")
        notes=pd.DataFrame([
            ["Application","CORPTRACE 2.0 – Corporate & Director Intelligence"],
            ["Generated (UTC)",datetime.now(timezone.utc).isoformat()],
            ["Primary input","Company names only; Director Register is optional"],
            ["Company discovery","QorpIQ free read-only MCP name search, subject to fair-use limits"],
            ["Director discovery","QorpIQ free read-only company-by-CIN lookup; board/DIN rows only where returned"],
            ["Data freshness","QorpIQ free MCP returns QorpIQ-held public registry data; it does not fetch live from MCA"],
            ["Source provenance","Provider and retrieval mode (Live API / SQLite cache) are separately recorded"],
            ["DIN validation","Eight-digit format check only; not proof of DIN validity or current status"],
            ["Audit limitation","Public-source screening is preliminary. Verify material findings against current official MCA/approved records."],
            ["Related party","Common directorship alone does not establish related-party status, control, conflict or misconduct."],
        ],columns=["Field","Value"])
        notes.to_excel(writer,index=False,sheet_name="Read Me & Limitations")
    buf.seek(0)
    return buf

init_db()
app=Dash(__name__,title="CORPTRACE | Corporate & Director Intelligence",suppress_callback_exceptions=True)
server=app.server
app.index_string="""<!DOCTYPE html><html><head>{%metas%}<title>CORPTRACE | Corporate & Director Intelligence</title>{%favicon%}{%css%}
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
</head><body>{%app_entry%}<footer>{%config%}{%scripts%}{%renderer%}</footer></body></html>"""

def panel(title,child,right=None,panel_id=None):
    return html.Div([html.Div([html.H3(title),right or html.Span("WORKSPACE",className="panel-tag")],className="panel-head"),child],className="panel",id=panel_id)

def data_table(table_id, columns, selectable=False):
    props=dict(id=table_id,data=[],columns=[{"name":c,"id":c} for c in columns],
        page_size=10,sort_action="native",filter_action="native",
        style_table={"overflowX":"auto"},
        style_header={"backgroundColor":"#F5F7FB","fontWeight":"700","color":NAVY,"padding":"11px","fontFamily":"DM Sans"},
        style_cell={"padding":"9px","fontFamily":"DM Sans","fontSize":"11px","maxWidth":"260px","overflow":"hidden","textOverflow":"ellipsis","textAlign":"left","borderBottom":"1px solid #EDF0F5"},
        style_data_conditional=[
            {"if":{"filter_query":'{Match Status} = "REVIEW REQUIRED"'},"backgroundColor":"#FFF8E8"},
            {"if":{"filter_query":'{DIN Validation} = "INVALID FORMAT"'},"backgroundColor":"#FFF0F0"}])
    if selectable:
        props.update(row_selectable="multi",selected_rows=[])
    return dash_table.DataTable(**props)

candidate_columns=[
    "Input Company Name","Legal Company Name","CIN/LLPIN","Company Status","State",
    "Date of Incorporation","Match Confidence","Match Status","Provider","Retrieval Mode","Source URL"
]
director_columns=[
    "Company Name","CIN/LLPIN","Director Name","DIN","Designation",
    "Appointment Date","Cessation Date","Director Status","DIN Validation",
    "Provider","Retrieval Mode","Source URL"
]

app.layout=html.Div([
    dcc.Store(id="company-store"),
    dcc.Store(id="candidate-store"),
    dcc.Store(id="confirmed-company-store"),
    dcc.Store(id="api-director-store"),
    dcc.Store(id="optional-director-store"),
    dcc.Store(id="evidence-store"),
    html.Aside([
        html.Div([html.Div("C",className="brand-mark"),html.Div([html.Div("CORPTRACE",className="brand-name"),html.Div("CORPORATE & DIRECTOR INTELLIGENCE",className="brand-sub")])],className="brand"),
        html.Div("WORKSPACE",className="nav-label"),
        html.Div([html.A([html.Span(ic),html.Span(label)],href="#"+target,className="nav-item"+(" active" if i==0 else "")) for i,(ic,label,target) in enumerate([
            ("▦","Company Input","input-data"),("▤","Company Verification","company-verification"),("♙","Director Intelligence","director-intelligence"),("⇄","Common Directors","common-directors"),("⌘","Network Analysis","network-analysis"),("◈","Evidence Centre","evidence-centre")])],className="nav-list"),
        html.Div("DATA & CONTROLS",className="nav-label"),
        html.Div([html.A([html.Span("⚙"),html.Span("Data Sources")],href="#data-sources",className="nav-item"),
                  html.A([html.Span("⇩"),html.Span("Export Evidence")],href="#export-reports",className="nav-item")],className="nav-list"),
        html.Div([html.Div("●",className="status-dot"),html.Div([html.Div("LOCAL WORKSPACE"),html.Small("Your uploaded files remain on this device")])],className="sidebar-status")
    ],className="sidebar"),
    html.Main([
        html.Div([html.Div([html.Div("CORPORATE RISK & GOVERNANCE",className="eyebrow"),html.H1("Know the company. Trace the connections."),html.P("Start with company names. Confirm CINs. Discover directors. Identify common DINs.")]),
                  html.Div([html.Div("●  CORPTRACE 2.0",className="system-pill"),html.Div(datetime.now().strftime("%d %b %Y"),className="date-pill")],className="top-actions")],className="topbar"),
        html.Div([
            html.Div([html.Div("01 / COMPANY INPUT",className="step-label"),html.H2("Start with company names"),html.P("Only a company-name list is mandatory. A Director Register is optional and is not required for director discovery.")],className="section-intro"),
            html.Div([
                html.Div([html.Div("A",className="upload-index"),html.H3("Company name list  ·  Required"),html.P("Excel or CSV · Column: Company Name"),
                    dcc.Upload(id="company-upload",children=html.Div([html.Div("↑",className="upload-icon"),html.B("Drop company file here"),html.Span(" or browse")]),className="dropzone",multiple=False),
                    html.Div(id="company-file-label",className="file-label")],className="upload-card"),
                html.Div([html.Div("B",className="upload-index"),html.H3("Director Register  ·  Optional"),html.P("Use only as a supplementary / fallback dataset"),
                    dcc.Upload(id="director-upload",children=html.Div([html.Div("＋",className="upload-icon"),html.B("Optional director file"),html.Span(" or browse")]),className="dropzone",multiple=False),
                    html.Div(id="director-file-label",className="file-label")],className="upload-card")
            ],className="upload-grid"),
            html.Div([html.Label("MATCH CONFIDENCE THRESHOLD"),dcc.Slider(id="threshold",min=70,max=100,step=1,value=85,marks={70:"70",80:"80",90:"90",100:"100"})],className="controls-row"),
        ],className="section-card",id="input-data"),
        html.Div([
            html.Div("02 / FREE DATA SOURCES",className="step-label"),
            html.Div([html.H2("Select permitted public sources"),html.P("No paid API is configured. QorpIQ Free is the primary company-search and company-by-CIN source.")],className="section-intro"),
            dcc.Checklist(id="source-select",options=[
                {"label":" QorpIQ Free MCP / REST — no key; fair-use limit","value":"QorpIQ Free"},
                {"label":" data.gov.in OGD Company Master — optional; free key required","value":"data.gov.in OGD"}
            ],value=["QorpIQ Free"],className="source-checklist"),
            html.Div([
                html.Div([html.Label("DATA.GOV.IN API KEY"),dcc.Input(id="ogd-key",type="password",placeholder="Optional free OGD API key",className="source-input")]),
                html.Div([html.Label("COMPANY MASTER RESOURCE ID"),dcc.Input(id="ogd-resource",placeholder="Optional resource UUID",className="source-input")]),
                html.Div([html.Label("COMPANY NAME FIELD"),dcc.Input(id="ogd-name-field",value="CompanyName",className="source-input")])
            ],className="source-config-grid"),
            html.Div([html.Button("1. Search company names  →",id="search-company-btn",n_clicks=0,className="primary-btn"),html.Div(id="search-status",className="run-status")],className="run-row"),
        ],className="section-card source-section",id="data-sources"),
        html.Div([
            html.Div("03 / COMPANY VERIFICATION",className="step-label"),
            html.Div([html.H2("Review and confirm company identity"),html.P("Select the correct legal entity for each uploaded name. Confirmed CINs are then used to retrieve the board/director list.")],className="section-intro"),
            panel("Company search candidates",data_table("candidate-table",candidate_columns,True),html.Span("SELECT CORRECT ENTITIES",className="panel-tag"),"company-verification"),
            html.Div([html.Button("2. Confirm selected companies & fetch directors  →",id="fetch-directors-btn",n_clicks=0,className="primary-btn"),html.Div(id="director-fetch-status",className="run-status")],className="run-row"),
        ],className="section-card"),
        html.Div([
            html.Div("04 / DIRECTOR INTELLIGENCE",className="step-label"),
            panel("Directors retrieved from confirmed CINs",data_table("director-table",director_columns),html.Span("COMPANY → BOARD → DIN",className="panel-tag"),"director-intelligence"),
            html.Div("Only director rows explicitly returned in the company-by-CIN response are displayed. Missing fields remain blank; no director links are inferred.",className="disclaimer")
        ],className="section-card"),
        html.Div([
            html.Div("05 / AUDIT ANALYTICS",className="step-label"),
            html.Div([html.Button("3. Run common-director analysis  →",id="run-btn",n_clicks=0,className="primary-btn"),html.Div(id="run-status",className="run-status")],className="run-row"),
            html.Div(id="results-area",children=html.Div("Confirm companies and retrieve director records to begin analysis.",className="empty-state"))
        ],className="section-card"),
        html.Div([html.Button("Download audit evidence workbook  ↓",id="download-btn",n_clicks=0,className="secondary-btn"),dcc.Download(id="download-data")],className="export-row",id="export-reports"),
        html.Div("Audit note: QorpIQ Free is a read-only third-party public-record service. It states that its free MCP uses QorpIQ-held records and does not fetch live from MCA. Verify material matters against current official MCA records.",className="disclaimer",id="evidence-centre"),
        html.Div([html.Span("CORPTRACE 2.0"),html.Span("Deterministic matching · Source traceability · Human confirmation")],className="footer")
    ],className="main-content")
],className="app-shell")

@app.callback(Output("company-store","data"),Output("company-file-label","children"),
              Input("company-upload","contents"),State("company-upload","filename"),prevent_initial_call=True)
def store_company(contents,filename):
    if not contents: return no_update,no_update
    try:
        df=read_upload(contents,filename)
        col=find_col(df,["Company Name","Company","Name"])
        if not col: return no_update,"Upload error: file must contain a Company Name column."
        df=df[[col]].rename(columns={col:"Company Name"})
        df=df[df["Company Name"].astype(str).str.strip().ne("")]
        return df.to_json(orient="split"),f"✓ {filename} · {len(df):,} company names"
    except Exception as e:
        return no_update,f"Upload error: {e}"

@app.callback(Output("optional-director-store","data"),Output("director-file-label","children"),
              Input("director-upload","contents"),State("director-upload","filename"),prevent_initial_call=True)
def store_optional_directors(contents,filename):
    if not contents: return no_update,no_update
    try:
        df=read_upload(contents,filename)
        if not find_col(df,["DIN","Director Identification Number"]):
            return no_update,"Upload error: optional register must contain a DIN column."
        return df.to_json(orient="split"),f"✓ Optional file loaded · {len(df)} rows"
    except Exception as e:
        return no_update,f"Upload error: {e}"

def _candidate_from_record(input_name,record,provider,mode,threshold):
    legal=record.get("Legal Company Name") or record.get("Company Name") or record.get("name") or ""
    cin=record.get("CIN/LLPIN") or record.get("CIN") or record.get("LLPIN") or ""
    if not legal or not cin: return None
    score=round(float(fuzz.WRatio(norm_name(input_name),norm_name(legal))),1)
    return {
        "Input Company Name":input_name,"Legal Company Name":legal,"CIN/LLPIN":cin,
        "Company Status":record.get("Company Status",""),"State":record.get("State",""),
        "Date of Incorporation":record.get("Date of Incorporation",""),
        "Match Confidence":score,"Match Status":"REVIEW REQUIRED" if score < threshold else "CANDIDATE – CONFIRM",
        "Provider":provider,"Retrieval Mode":mode,"Source URL":record.get("Source URL","")
    }

@app.callback(Output("candidate-store","data"),Output("candidate-table","data"),
              Output("evidence-store","data"),Output("search-status","children"),
              Input("search-company-btn","n_clicks"),State("company-store","data"),
              State("source-select","value"),State("threshold","value"),
              State("ogd-key","value"),State("ogd-resource","value"),State("ogd-name-field","value"),
              prevent_initial_call=True)
def search_company_names(n,company_json,selected,threshold,ogd_key,ogd_resource,ogd_name_field):
    if not company_json:
        return [],[] ,[],"Upload a company-name list first."
    selected=list(selected or [])
    if not selected:
        return [],[],[],"Select at least one source."
    if "data.gov.in OGD" in selected and (not str(ogd_key or "").strip() or not str(ogd_resource or "").strip()):
        selected.remove("data.gov.in OGD")
        notices=["data.gov.in skipped: both API key and resource ID are required. It is a company-master source only."]
    else:
        notices=[]
    cdf=pd.read_json(io.StringIO(company_json),orient="split",dtype=False)
    names=cdf["Company Name"].astype(str).str.strip().drop_duplicates().tolist()
    candidates=[]; evidence=[]
    for name in names[:40]:
        found,errors=source_engine.fetch_company(name,selected,{"api_key":ogd_key,"resource_id":ogd_resource,"name_field":ogd_name_field or "CompanyName"})
        notices.extend(errors)
        for item in found:
            provider,mode=source_engine.split_source_label(item.get("source"))
            normalized=source_engine.normalize_company_candidates(item.get("payload"),name,provider,mode)
            for rec in normalized:
                row=_candidate_from_record(name,rec,provider,mode,int(threshold))
                if row:
                    candidates.append(row)
                    evidence.append({"Stage":"Company Search","Query":name,**row,"Retrieved At (UTC)":datetime.now(timezone.utc).isoformat()})
    # de-duplicate repeated candidate CINs per uploaded name
    seen=set(); unique=[]
    for row in candidates:
        key=(row["Input Company Name"],row["CIN/LLPIN"])
        if key not in seen: seen.add(key); unique.append(row)
    status=f"Search complete · {len(names)} names searched · {len(unique)} candidates · {len(notices)} notices"
    if not unique and not notices: notices.append("No company candidates returned by selected sources.")
    return unique,unique,evidence, status + ((" | " + " ".join(notices[:4])) if notices else "")

@app.callback(Output("api-director-store","data"),Output("confirmed-company-store","data"),
              Output("director-table","data"),Output("director-fetch-status","children"),
              Output("evidence-store","data",allow_duplicate=True),
              Input("fetch-directors-btn","n_clicks"),State("candidate-table","selected_rows"),
              State("candidate-table","data"),State("evidence-store","data"),
              prevent_initial_call=True)
def fetch_directors_for_confirmed_cins(n,selected_rows,candidate_rows,evidence):
    if not selected_rows:
        return None,[],[],"Select one or more company candidates to confirm first.",evidence or []
    selected=[candidate_rows[i] for i in selected_rows if 0<=i<len(candidate_rows)]
    # A single uploaded name must resolve to one confirmed legal entity.
    name_counts={}
    for row in selected:
        key=str(row.get("Input Company Name","")).strip().casefold()
        name_counts[key]=name_counts.get(key,0)+1
    duplicated={k for k,v in name_counts.items() if v>1}
    confirmed=[]; directors=[]; evidence=list(evidence or []); notices=[]
    for company in selected:
        input_key=str(company.get("Input Company Name","")).strip().casefold()
        if input_key in duplicated:
            notices.append(f"{company.get('Input Company Name')}: more than one candidate selected. Select only one legal entity for each uploaded company name.")
            continue
        cin=str(company.get("CIN/LLPIN","")).strip().upper()
        if not cin:
            notices.append(f"No CIN/LLPIN for {company.get('Legal Company Name','unknown')}; skipped.")
            continue
        # This free endpoint is the key company-name -> CIN -> board/DIN step.
        try:
            payload,label=source_engine.qorpiq_company(cin)
            provider,mode=source_engine.split_source_label(label)
            legal=company.get("Legal Company Name","")
            master=source_engine.normalize_company_master(payload)
            legal=master.get("company_name") or master.get("name") or master.get("legal_name") or legal
            company_status=master.get("company_status") or master.get("status") or company.get("Company Status","")
            state=master.get("state") or master.get("registered_state") or company.get("State","")
            incorporation=master.get("date_of_incorporation") or master.get("incorporation_date") or company.get("Date of Incorporation","")
            profile_url=master.get("source_url") or company.get("Source URL","")
            confirmed_row={**company,"Legal Company Name":legal,"Company Status":company_status,
                           "State":state,"Date of Incorporation":incorporation,
                           "Source URL":profile_url,"Confirmation":"Auditor selected candidate",
                           "Confirmed At (UTC)":datetime.now(timezone.utc).isoformat()}
            confirmed.append(confirmed_row)
            board=source_engine.extract_company_board_directors(payload,cin,legal)
            if not board:
                notices.append(f"{legal}: company profile returned but no supported board/director array was present. No director rows were invented.")
            for row in board:
                din=clean_din(row.get("DIN"))
                row["DIN"]=din or str(row.get("DIN",""))
                row["DIN Validation"]="VALID FORMAT" if din else "INVALID FORMAT"
                row["Provider"]=provider
                row["Retrieval Mode"]=mode
                row["Retrieved At (UTC)"]=datetime.now(timezone.utc).isoformat()
                if not row.get("Source URL"): row["Source URL"]=profile_url
                directors.append(row)
            evidence.append({"Stage":"Company by CIN / Board Lookup","Query":cin,"Provider":provider,"Retrieval Mode":mode,
                             "Retrieved At (UTC)":datetime.now(timezone.utc).isoformat(),"Director Rows Returned":len(board),
                             "Source URL":company.get("Source URL","")})
        except Exception as exc:
            notices.append(f"{cin}: {exc}")
    status=f"Company confirmation complete · {len(confirmed)} selected · {len(directors)} director rows retrieved"
    if notices: status += " | " + " ".join(notices[:5])
    director_json=pd.DataFrame(directors).to_json(orient="split") if directors else None
    return director_json,confirmed,directors,status,evidence

@app.callback(Output("results-area","children"),Output("run-status","children"),
              Input("run-btn","n_clicks"),State("company-store","data"),
              State("confirmed-company-store","data"),State("api-director-store","data"),
              State("optional-director-store","data"),State("threshold","value"),
              prevent_initial_call=True)
def run_analysis(n,company_json,confirmed,api_json,optional_json,threshold):
    if not company_json: return no_update,"Upload company names first."
    if not confirmed: return no_update,"Search and confirm at least one company, then fetch directors."
    try:
        companies=pd.read_json(io.StringIO(company_json),orient="split",dtype=False)
        master=pd.DataFrame([{"Company Name":x.get("Legal Company Name",""),"CIN":x.get("CIN/LLPIN","")} for x in confirmed])
        matched=resolve_company_names(companies,master,threshold=int(threshold))
        # An explicit user selection is the legal-entity confirmation event.
        confirmed_by_input={str(x.get("Input Company Name","")).strip().casefold():x for x in confirmed}
        for idx, mrow in matched.iterrows():
            selected_entity=confirmed_by_input.get(str(mrow.get("Input Company Name","")).strip().casefold())
            if selected_entity:
                matched.at[idx,"Matched Legal Name"]=selected_entity.get("Legal Company Name","")
                matched.at[idx,"CIN/LLPIN"]=selected_entity.get("CIN/LLPIN","")
                matched.at[idx,"Match Status"]="AUDITOR CONFIRMED"
                matched.at[idx,"Match Method"]="Auditor-selected candidate; company-by-CIN lookup completed"
        frames=[]
        if api_json:
            df=pd.read_json(io.StringIO(api_json),orient="split",dtype=False)
            if not df.empty: frames.append(df)
        if optional_json:
            df=pd.read_json(io.StringIO(optional_json),orient="split",dtype=False)
            if not df.empty: frames.append(df)
        director_raw=pd.concat(frames,ignore_index=True,sort=False).fillna("") if frames else pd.DataFrame()
        if not director_raw.empty:
            director_clean,common=director_analysis(director_raw)
        else:
            director_clean,common=pd.DataFrame(),pd.DataFrame()
        if len(common):
            top=common.head(15).sort_values("Company_Count")
            fig=px.bar(top,x="Company_Count",y="Director",orientation="h",color="Company_Count",
                       color_continuous_scale=["#AFC2FF",BLUE],labels={"Company_Count":"Companies","Director":"Director"})
            fig.update_layout(margin=dict(l=5,r=5,t=5,b=5),paper_bgcolor="white",plot_bgcolor="white",coloraxis_showscale=False)
        else:
            fig=go.Figure(); fig.add_annotation(text="No common DINs across the confirmed companies.",showarrow=False)
            fig.update_layout(paper_bgcolor="white",plot_bgcolor="white")
        def table(df):
            if df.empty: return html.Div("No records available.",className="empty-small")
            return dash_table.DataTable(data=df.fillna("").to_dict("records"),columns=[{"name":c,"id":c} for c in df.columns],
                page_size=10,sort_action="native",filter_action="native",style_table={"overflowX":"auto"},
                style_header={"backgroundColor":"#F5F7FB","fontWeight":"700","padding":"10px"},
                style_cell={"fontSize":"11px","padding":"8px","maxWidth":"260px","overflow":"hidden","textOverflow":"ellipsis"})
        content=html.Div([
            html.Div([html.Div([html.Div("COMPANIES CONFIRMED",className="metric-label"),html.Div(str(len(confirmed)),className="metric-value")],className="metric-card"),
                      html.Div([html.Div("DIRECTOR RECORDS",className="metric-label"),html.Div(str(len(director_clean)),className="metric-value")],className="metric-card"),
                      html.Div([html.Div("COMMON DINs",className="metric-label"),html.Div(str(len(common)),className="metric-value")],className="metric-card")],className="metric-grid"),
            html.Div([panel("Common director connectivity",dcc.Graph(figure=fig,config={"displayModeBar":False}),panel_id="network-analysis")],className="chart-grid"),
            panel("Company matching results",table(matched),panel_id="company-matching-results"),
            panel("Director details and DIN validation",table(director_clean),panel_id="director-results"),
            panel("Common directors",table(common),panel_id="common-directors")
        ])
        app.server.config["last_companies"]=matched
        app.server.config["last_confirmed"]=pd.DataFrame(confirmed)
        app.server.config["last_directors"]=director_clean
        app.server.config["last_common"]=common
        return content,f"Analysis complete · {len(confirmed)} companies · {len(director_clean)} director records · {len(common)} common DINs"
    except Exception as exc:
        return no_update,f"Analysis error: {exc}"

@app.callback(Output("download-data","data"),Input("download-btn","n_clicks"),State("evidence-store","data"),prevent_initial_call=True)
def download_evidence(n,evidence):
    if not n: return no_update
    c=app.server.config.get("last_companies",pd.DataFrame())
    confirmed=app.server.config.get("last_confirmed",pd.DataFrame())
    d=app.server.config.get("last_directors",pd.DataFrame())
    common=app.server.config.get("last_common",pd.DataFrame())
    if c.empty: return no_update
    buf=make_workbook(c,confirmed,d,common,evidence or [])
    return dcc.send_bytes(buf.getvalue(),f"CORPTRACE_Audit_Evidence_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")

if __name__=="__main__":
    host=os.getenv("CORPTRACE_HOST","127.0.0.1")
    port=int(os.getenv("CORPTRACE_PORT","8050"))
    app.run(host=host,port=port,debug=False)
