@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Virtual environment not found. Running setup first...
  call setup.bat
  if errorlevel 1 exit /b 1
)
call .venv\Scripts\activate.bat
python -c "import dash, pandas, plotly, rapidfuzz, requests, openpyxl" >nul 2>&1
if errorlevel 1 (
  echo Some dependencies are missing. Installing requirements...
  python -m pip install -r requirements.txt
  if errorlevel 1 goto error
)
echo.
echo Starting CORPTRACE 2.0...
echo Open http://127.0.0.1:8050 in your browser.
python app.py
pause
exit /b 0
:error
echo Application could not start. Check the error above.
pause
exit /b 1
