# CORPTRACE 2.0 — Test Results

Executed in the build environment:

- Python syntax compilation: passed for `app.py`, `source_engine.py`, `corptrace_core.py` and all test modules.
- Automated regression suite: **33 passed**.
- Coverage includes:
  - Company-name-only input format.
  - Company search response parsing and CIN/LLPIN candidate extraction.
  - Free QorpIQ endpoint request construction without an API-key header.
  - Company-by-CIN endpoint request construction.
  - Board/director row extraction from snake_case and camelCase JSON structures.
  - DIN leading-zero preservation and numeric JSON normalization.
  - Common-DIN aggregation by confirmed CIN/LLPIN.
  - No invented directors when no supported board array is returned.
  - Source provenance and cache-vs-live labels.
  - TLS certificate verification.
  - Blank data.gov.in credentials.
  - Application workflow wiring and CORPTRACE branding.

Not executed in the build environment:
- Dash browser runtime / interactive Windows UI: Dash is not installed in the build runtime, so no browser-level smoke test is claimed.
- External QorpIQ connectivity: live API calls were not executed from this build runtime. Endpoint paths and capabilities were checked against QorpIQ's published documentation; actual uptime, response coverage and network fair-use availability must be tested from the user's Windows laptop.
- Live data.gov.in resource access: requires the user's own free API key, active resource ID and correct resource field; not tested.

The unit tests use mocked JSON responses for provider schemas. They establish deterministic parsing and application workflow logic, not live provider uptime, freshness or completeness.
